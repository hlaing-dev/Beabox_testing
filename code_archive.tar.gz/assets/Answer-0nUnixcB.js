import{j as r}from"./index-BX-O1sI1.js";const t=()=>r.jsx("div",{});export{t as default};
