import{j as r}from"./index-CI_Ed5g9.js";const i=({show:s})=>r.jsx("div",{className:`${s?"block":"hidden"} w-full h-[1px] bg-[#FFFFFF0A]`});export{i as D};
