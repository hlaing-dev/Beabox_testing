import{j as s}from"./index-BX-O1sI1.js";const r=()=>s.jsx("div",{children:"UploadProcess"});export{r as default};
