import{j as s}from"./index-CI_Ed5g9.js";const r=()=>s.jsx("div",{children:"UploadProcess"});export{r as default};
