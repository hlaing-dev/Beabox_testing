const s="/assets/shield-DoEPKM5p.png";export{s as S};
