import{j as r}from"./index-CI_Ed5g9.js";const t=()=>r.jsx("div",{});export{t as default};
